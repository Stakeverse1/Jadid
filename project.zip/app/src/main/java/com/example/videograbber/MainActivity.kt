package com.example.videograbber

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONTokener
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val cBg = Color.parseColor("#F4F5F9")
    private val cPrimary = Color.parseColor("#4F46E5")
    private val cText = Color.parseColor("#1F2330")
    private val cSub = Color.parseColor("#6B7280")
    private val cOk = Color.parseColor("#16A34A")
    private val cErr = Color.parseColor("#DC2626")
    private val cWarn = Color.parseColor("#F59E0B")
    private val cSoft = Color.parseColor("#E0E7FF")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var pageBar: ProgressBar
    private lateinit var fab: TextView
    private lateinit var repairBanner: TextView
    private lateinit var browserPage: FrameLayout
    private lateinit var dlPage: LinearLayout
    private lateinit var dlList: LinearLayout
    private lateinit var dlEmpty: TextView
    private lateinit var tabBrowser: TextView
    private lateinit var tabDl: TextView
    private lateinit var concChip: TextView

    private val items = ArrayList<Media>()
    private val seen = HashSet<String>()
    private val variantUrls = HashSet<String>()
    private val probePool = Executors.newFixedThreadPool(4)
    private val ui = Handler(Looper.getMainLooper())
    private val views = HashMap<Long, TaskView>()
    private var shownIds: List<Long> = emptyList()
    private var repairTask: Task? = null
    private var onDownloads = false

    @Volatile private var pageUrl = ""

    private val scanner = object : Runnable {
        override fun run() {
            if (!onDownloads) scan()
            ui.postDelayed(this, 2500)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateTabs()
            if (onDownloads) renderTasks()
            ui.postDelayed(this, 700)
        }
    }

    // ---------- Small UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private fun rect(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun chip(text: String, bg: Int, fg: Int, click: () -> Unit): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = 13f
        v.setTextColor(fg)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(14), dp(8), dp(14), dp(8))
        v.background = rect(bg, 18)
        v.setOnClickListener { click() }
        return v
    }

    private fun icon(sym: String, click: () -> Unit): TextView {
        val v = TextView(this)
        v.text = sym
        v.textSize = 22f
        v.setTextColor(cPrimary)
        v.gravity = Gravity.CENTER
        v.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        v.setOnClickListener { click() }
        return v
    }

    // ---------- Lifecycle ----------

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Downloads.init(applicationContext)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        // ----- WebView -----
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        Downloads.ua = web.settings.userAgentString
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                pageBar.progress = newProgress
                pageBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url.toString()
                if (looksLikeMedia(u)) found(u, r.requestHeaders["Referer"] ?: pageUrl)
                return null
            }

            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                pageUrl = url
                if (!urlBox.hasFocus()) urlBox.setText(url)
                items.clear()
                seen.clear()
                variantUrls.clear()
                updateFab()
            }

            override fun onPageFinished(v: WebView, url: String) {
                scan()
            }
        }
        web.setDownloadListener { url, _, _, mime, _ ->
            if (mime != null && mime.startsWith("video")) {
                Downloads.add(Media(url, "", pageUrl, false, 0), pageUrl)
                Toast.makeText(this, "به دانلودها اضافه شد", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "فقط دانلود ویدیو پشتیبانی می‌شود", Toast.LENGTH_SHORT).show()
            }
        }

        // ----- Top bar -----
        urlBox = EditText(this)
        urlBox.hint = "جستجو یا آدرس سایت"
        urlBox.textSize = 14f
        urlBox.setSingleLine(true)
        urlBox.setTextColor(cText)
        urlBox.background = rect(Color.parseColor("#EEF0F5"), 22)
        urlBox.setPadding(dp(16), dp(10), dp(16), dp(10))
        urlBox.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlBox.imeOptions = EditorInfo.IME_ACTION_GO
        urlBox.setOnEditorActionListener { _, _, _ ->
            go()
            true
        }

        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.layoutDirection = View.LAYOUT_DIRECTION_LTR
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setBackgroundColor(Color.WHITE)
        topBar.setPadding(dp(8), dp(6), dp(8), dp(6))
        topBar.addView(icon("←") { if (web.canGoBack()) web.goBack() })
        val urlLp = lp(0, WRAP, 4, 0, 4, 0)
        urlLp.weight = 1f
        topBar.addView(urlBox, urlLp)
        topBar.addView(icon("⟳") { web.reload() })

        pageBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pageBar.max = 100
        pageBar.progressTintList = ColorStateList.valueOf(cPrimary)
        pageBar.visibility = View.GONE

        repairBanner = tv(
            "🔧 حالت تعمیر لینک: ویدیو رو دوباره پلی کن تا لینک تازه پیدا بشه (لمس = لغو)",
            13f, Color.WHITE, true
        )
        repairBanner.setBackgroundColor(cWarn)
        repairBanner.setPadding(dp(12), dp(10), dp(12), dp(10))
        repairBanner.visibility = View.GONE
        repairBanner.setOnClickListener {
            repairTask = null
            repairBanner.visibility = View.GONE
            updateFab()
        }

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.addView(topBar)
        column.addView(pageBar, LinearLayout.LayoutParams(MATCH, dp(3)))
        column.addView(repairBanner)
        column.addView(web, LinearLayout.LayoutParams(MATCH, 0, 1f))

        fab = chip("", cPrimary, Color.WHITE) { showSheet() }
        fab.textSize = 15f
        fab.typeface = Typeface.DEFAULT_BOLD
        fab.elevation = dp(8).toFloat()
        fab.setPadding(dp(22), dp(12), dp(22), dp(12))
        fab.visibility = View.GONE

        browserPage = FrameLayout(this)
        browserPage.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
        val fabLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabLp.bottomMargin = dp(24)
        browserPage.addView(fab, fabLp)

        // ----- Downloads page -----
        concChip = chip("", cSoft, cPrimary) {
            val n = Downloads.concurrent % 5 + 1
            Downloads.setConcurrent(n)
            updateConcChip()
        }
        val clearChip = chip("🧹 پاک کردن تمام‌شده‌ها", Color.parseColor("#E5E7EB"), cText) {
            Downloads.clearDone()
        }
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.addView(concChip)
        chips.addView(clearChip, lp(WRAP, WRAP, 8, 0, 0, 0))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(16), dp(16), dp(16), dp(8))
        head.addView(tv("دانلودها", 22f, cText, true))
        head.addView(chips, lp(WRAP, WRAP, 0, 10, 0, 0))

        dlList = LinearLayout(this)
        dlList.orientation = LinearLayout.VERTICAL
        dlList.setPadding(dp(12), dp(4), dp(12), dp(16))

        dlEmpty = tv("هنوز دانلودی نیست.\nیه ویدیو رو تو مرورگر پلی کن و دکمه آبی پایین صفحه رو بزن.", 14f, cSub)
        dlEmpty.gravity = Gravity.CENTER
        dlEmpty.setPadding(dp(24), dp(60), dp(24), dp(24))

        val sv = ScrollView(this)
        sv.addView(dlList)

        dlPage = LinearLayout(this)
        dlPage.orientation = LinearLayout.VERTICAL
        dlPage.setBackgroundColor(cBg)
        dlPage.addView(head)
        val svLp = lp(MATCH, 0)
        svLp.weight = 1f
        dlPage.addView(sv, svLp)

        // ----- Tabs -----
        tabBrowser = tv("🌐 مرورگر", 14f, cPrimary, true)
        tabBrowser.gravity = Gravity.CENTER
        tabBrowser.setPadding(0, dp(14), 0, dp(14))
        tabBrowser.setOnClickListener { selectTab(false) }
        tabDl = tv("⬇ دانلودها", 14f, cSub, true)
        tabDl.gravity = Gravity.CENTER
        tabDl.setPadding(0, dp(14), 0, dp(14))
        tabDl.setOnClickListener { selectTab(true) }

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setBackgroundColor(Color.WHITE)
        tabs.elevation = dp(8).toFloat()
        val t1 = lp(0, WRAP)
        t1.weight = 1f
        val t2 = lp(0, WRAP)
        t2.weight = 1f
        tabs.addView(tabBrowser, t1)
        tabs.addView(tabDl, t2)

        val pages = FrameLayout(this)
        pages.addView(browserPage, FrameLayout.LayoutParams(MATCH, MATCH))
        pages.addView(dlPage, FrameLayout.LayoutParams(MATCH, MATCH))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(cBg)
        val pagesLp = lp(MATCH, 0)
        pagesLp.weight = 1f
        root.addView(pages, pagesLp)
        root.addView(tabs, lp(MATCH, WRAP))
        setContentView(root)

        updateConcChip()
        selectTab(false)
        web.loadUrl("https://www.google.com")
    }

    override fun onResume() {
        super.onResume()
        ui.post(scanner)
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(scanner)
        ui.removeCallbacks(ticker)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (onDownloads) selectTab(false)
        else if (web.canGoBack()) web.goBack()
        else super.onBackPressed()
    }

    private fun go() {
        var t = urlBox.text.toString().trim()
        if (t.isEmpty()) return
        if (!t.startsWith("http")) {
            t = if (t.contains(".") && !t.contains(" ")) "https://$t"
            else "https://www.google.com/search?q=" + Uri.encode(t)
        }
        urlBox.clearFocus()
        web.loadUrl(t)
    }

    private fun selectTab(dl: Boolean) {
        onDownloads = dl
        if (dl) {
            web.evaluateJavascript("document.querySelectorAll('video').forEach(function(v){v.pause()})", null)
        }
        browserPage.visibility = if (dl) View.GONE else View.VISIBLE
        dlPage.visibility = if (dl) View.VISIBLE else View.GONE
        tabBrowser.setTextColor(if (dl) cSub else cPrimary)
        tabDl.setTextColor(if (dl) cPrimary else cSub)
        if (dl) renderTasks()
    }

    private fun updateTabs() {
        val n = Downloads.tasks.count { it.state == St.RUNNING || it.state == St.QUEUED }
        tabDl.text = if (n > 0) "⬇ دانلودها ($n)" else "⬇ دانلودها"
    }

    private fun updateConcChip() {
        concChip.text = "⚙ همزمان: ${Downloads.concurrent}"
    }

    // ---------- Detection ----------

    private fun looksLikeMedia(u: String): Boolean {
        val p = Downloads.path(u)
        return p.endsWith(".mp4") || p.endsWith(".m3u8") || p.endsWith(".webm") ||
            p.endsWith(".mkv") || p.endsWith(".mov") || p.endsWith(".m4v") ||
            p.endsWith(".flv") || p.endsWith(".3gp")
    }

    private fun scan() {
        val js = "(function(){var r=[];document.querySelectorAll('video,video source').forEach(function(e){" +
            "var s=e.currentSrc||e.src;if(s&&s.indexOf('http')===0)r.push(s)});return JSON.stringify(r)})()"
        web.evaluateJavascript(js) { raw ->
            try {
                val inner = JSONTokener(raw).nextValue() as? String ?: return@evaluateJavascript
                val arr = JSONArray(inner)
                for (i in 0 until arr.length()) found(arr.getString(i), pageUrl)
            } catch (e: Exception) {
            }
        }
    }

    private fun found(u: String, ref: String) {
        ui.post {
            if (seen.add(u)) {
                probePool.execute { probe(u, ref) }
            }
        }
    }

    private fun probe(u: String, ref: String) {
        val isHls = Downloads.path(u).endsWith(".m3u8")
        try {
            if (isHls) {
                hlsEntries(u, ref)
                return
            }
            val c = Downloads.open(u, ref, "HEAD")
            val len = c.contentLengthLong
            val type = (c.contentType ?: "").lowercase()
            c.disconnect()
            if (type.startsWith("text/") || type.contains("json") || type.startsWith("image/")) return
            if (type.contains("mpegurl")) {
                hlsEntries(u, ref)
                return
            }
            if (len in 1L..100_000L) return
            val ext = Downloads.extOf(u, "mp4").uppercase()
            val label = if (len > 0) "$ext • ${Downloads.fmt(len)}" else ext
            ui.post { add(Media(u, label, ref, false, 0)) }
        } catch (e: Exception) {
            ui.post { add(Media(u, if (isHls) "HLS" else "ویدیو", ref, isHls, 0)) }
        }
    }

    private fun hlsEntries(u: String, ref: String) {
        val txt = Downloads.readText(u, ref)
        val v = Downloads.parseVariants(txt, URL(u), ref)
        ui.post {
            if (v.isEmpty()) {
                add(Media(u, "HLS", ref, true, 0))
            } else {
                v.forEach { variantUrls.add(it.url) }
                items.removeAll { it.url in variantUrls && it.label == "HLS" }
                v.forEach { add(it) }
            }
        }
    }

    private fun add(m: Media) {
        if (m.label == "HLS" && m.url in variantUrls) return
        if (items.any { it.url == m.url }) return
        items.add(m)
        updateFab()
        val rt = repairTask
        if (rt != null && sameVideo(rt, m)) applyRepair(rt, m)
    }

    private fun updateFab() {
        fab.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        fab.text = if (repairTask != null) "🔧 ${items.size} لینک پیدا شد" else "⬇ ${items.size} ویدیو پیدا شد"
    }

    // ---------- Link repair ----------

    private fun startRepair(t: Task) {
        repairTask = t
        repairBanner.visibility = View.VISIBLE
        selectTab(false)
        items.clear()
        seen.clear()
        variantUrls.clear()
        updateFab()
        web.loadUrl(t.pageUrl)
        Toast.makeText(this, "ویدیو رو پلی کن تا لینک تازه پیدا بشه", Toast.LENGTH_LONG).show()
    }

    private fun sameVideo(t: Task, m: Media): Boolean {
        if (t.hls != m.hls) return false
        val a = Downloads.path(m.url).substringAfterLast('/')
        val b = Downloads.path(t.url).substringAfterLast('/')
        if (t.hls) return m.label == t.label || a == b
        return a.isNotEmpty() && a == b
    }

    private fun applyRepair(t: Task, m: Media) {
        Downloads.relink(t, m.url, m.ref)
        repairTask = null
        repairBanner.visibility = View.GONE
        Toast.makeText(this, "لینک تازه شد؛ دانلود ادامه پیدا می‌کنه", Toast.LENGTH_LONG).show()
        Downloads.resume(t)
        updateFab()
        selectTab(true)
    }

    // ---------- Found-videos sheet ----------

    private fun showSheet() {
        if (items.isEmpty()) return
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        val r = dp(24).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)

        val sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.layoutDirection = View.LAYOUT_DIRECTION_RTL
        sheet.setPadding(dp(16), dp(18), dp(16), dp(16))
        sheet.background = bg

        val rt = repairTask
        sheet.addView(tv(if (rt != null) "🔧 لینک تازه رو برای تعمیر انتخاب کن" else "ویدیوهای پیدا شده", 17f, cText, true))
        sheet.addView(tv("برای کپی لینک، روی هر مورد نگه دار", 12f, cSub), lp(WRAP, WRAP, 0, 2, 0, 10))

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        for (m in items.toList()) list.addView(foundCard(m, d), lp(MATCH, WRAP, 0, 0, 0, 8))

        val sv = ScrollView(this)
        sv.addView(list)
        val maxH = (resources.displayMetrics.heightPixels * 0.6).toInt()
        sheet.addView(sv, LinearLayout.LayoutParams(MATCH, minOf(maxH, items.size * dp(88) + dp(8))))

        d.setContentView(sheet)
        val w = d.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun foundCard(m: Media, d: Dialog): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(14), dp(12), dp(14), dp(12))
        card.background = rect(cBg, 14)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(if (m.label.isEmpty()) "ویدیو" else m.label, 16f, cText, true))
        val nameTv = tv(Downloads.path(m.url).substringAfterLast('/').take(34), 12f, cSub)
        nameTv.textDirection = View.TEXT_DIRECTION_LTR
        col.addView(nameTv)
        val colLp = lp(0, WRAP)
        colLp.weight = 1f
        card.addView(col, colLp)

        val rt = repairTask
        val btn = chip(if (rt != null) "استفاده" else "⬇ دانلود", cPrimary, Color.WHITE) {}
        var added = false
        btn.setOnClickListener {
            if (rt != null) {
                applyRepair(rt, m)
                d.dismiss()
            } else if (!added) {
                added = true
                Downloads.add(m, pageUrl)
                btn.text = "✓ اضافه شد"
                btn.background = rect(cOk, 18)
                updateTabs()
            }
        }
        card.addView(btn)

        card.setOnLongClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("url", m.url))
            Toast.makeText(this, "لینک کپی شد", Toast.LENGTH_SHORT).show()
            true
        }
        return card
    }

    // ---------- Downloads list ----------

    private fun renderTasks() {
        val list = Downloads.tasks.reversed()
        val ids = list.map { it.id }
        if (ids != shownIds) {
            shownIds = ids
            dlList.removeAllViews()
            views.keys.retainAll(ids.toSet())
            if (list.isEmpty()) {
                dlList.addView(dlEmpty)
            } else {
                for (t in list) {
                    val v = views.getOrPut(t.id) { TaskView(t) }
                    dlList.addView(v.card, lp(MATCH, WRAP, 0, 0, 0, 10))
                }
            }
        }
        for (t in list) views[t.id]?.update()
    }

    private fun confirmCancel(t: Task) {
        if (t.state == St.DONE || t.state == St.ERROR) {
            Downloads.cancel(t)
            return
        }
        AlertDialog.Builder(this)
            .setMessage("دانلود لغو بشه و فایل ناقص حذف بشه؟")
            .setPositiveButton("بله، لغو") { _, _ -> Downloads.cancel(t) }
            .setNegativeButton("نه", null)
            .show()
    }

    private fun play(t: Task) {
        val u = t.uri ?: return
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(Uri.parse(u), t.mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "پلیر پیدا نشد؛ فایل تو Movies/VideoGrabber هست", Toast.LENGTH_LONG).show()
        }
    }

    private inner class TaskView(val t: Task) {
        val card = LinearLayout(this@MainActivity)
        val title = tv(t.title, 15f, cText, true)
        val info = tv("", 12f, cSub)
        val bar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal)
        val b1 = chip("", cPrimary, Color.WHITE) {}
        val b2 = chip("", cSoft, cPrimary) {}
        val b3 = chip("", Color.parseColor("#FEE2E2"), cErr) {}

        init {
            bar.max = 1000
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(16), dp(14), dp(16), dp(14))
            card.background = rect(Color.WHITE, 16)
            card.elevation = dp(2).toFloat()
            card.addView(title)
            card.addView(info, lp(WRAP, WRAP, 0, 4, 0, 0))
            card.addView(bar, lp(MATCH, dp(6), 0, 10, 0, 0))
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.addView(b1)
            row.addView(b2, lp(WRAP, WRAP, 8, 0, 0, 0))
            row.addView(b3, lp(WRAP, WRAP, 8, 0, 0, 0))
            card.addView(row, lp(WRAP, WRAP, 0, 10, 0, 0))
        }

        private fun show(b: TextView, text: String, action: () -> Unit) {
            b.visibility = View.VISIBLE
            b.text = text
            b.setOnClickListener { action() }
        }

        fun update() {
            val st = t.state
            val pct: Int = if (t.hls && t.segTotal > 0) {
                t.segDone * 1000 / t.segTotal
            } else if (!t.hls && t.total > 0) {
                (t.done * 1000 / t.total).toInt()
            } else {
                0
            }
            val pTxt = if (pct > 0) "${pct / 10}% • " else ""
            val sizeTxt = Downloads.fmt(t.done)

            bar.isIndeterminate = (st == St.RUNNING && pct == 0 && t.done == 0L)
            bar.progress = if (st == St.DONE) 1000 else pct
            val tint = when (st) {
                St.DONE -> cOk
                St.ERROR -> cErr
                St.PAUSED -> cWarn
                else -> cPrimary
            }
            bar.progressTintList = ColorStateList.valueOf(tint)

            info.text = when (st) {
                St.QUEUED -> "⏳ در صف…"
                St.RUNNING -> {
                    val seg = if (t.hls && t.segTotal > 0) "قطعه ${t.segDone}/${t.segTotal} • " else ""
                    val tot = if (!t.hls && t.total > 0) " / ${Downloads.fmt(t.total)}" else ""
                    "⬇ $pTxt$seg$sizeTxt$tot • ${Downloads.fmt(t.speed)}/s"
                }
                St.PAUSED -> "⏸ متوقف • $pTxt$sizeTxt"
                St.ERROR -> "❌ ${t.msg}"
                St.DONE -> "✅ کامل شد • $sizeTxt • Movies/VideoGrabber"
            }

            b2.visibility = View.GONE
            when (st) {
                St.QUEUED, St.RUNNING -> {
                    show(b1, "⏸ توقف") { Downloads.pause(t) }
                    show(b3, "✕ لغو") { confirmCancel(t) }
                }
                St.PAUSED -> {
                    show(b1, "▶ ادامه") { Downloads.resume(t) }
                    show(b2, "🔧 تعمیر لینک") { startRepair(t) }
                    show(b3, "✕ لغو") { confirmCancel(t) }
                }
                St.ERROR -> {
                    show(b1, "↻ تلاش دوباره") { Downloads.resume(t) }
                    show(b2, "🔧 تعمیر لینک") { startRepair(t) }
                    show(b3, "✕ حذف") { confirmCancel(t) }
                }
                St.DONE -> {
                    show(b1, "▶ پخش") { play(t) }
                    show(b3, "🗑 حذف از لیست") { Downloads.cancel(t) }
                }
            }
        }
    }
}
