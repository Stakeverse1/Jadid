package com.example.videograbber

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONTokener
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

data class Media(
    val url: String,
    val label: String,
    val ref: String,
    val hls: Boolean,
    val bw: Long
)

class Seg(val url: String, val key: ByteArray?, val iv: ByteArray?)

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var urlBox: EditText
    private lateinit var fab: TextView
    private lateinit var status: TextView

    private val items = ArrayList<Media>()
    private val seen = HashSet<String>()
    private val variantUrls = HashSet<String>()
    private val io = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var pageUrl = ""
    @Volatile private var ua = ""

    private val scanner = object : Runnable {
        override fun run() {
            scan()
            ui.postDelayed(this, 2500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)

        urlBox = EditText(this).apply {
            hint = "آدرس سایت یا جستجو"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> go(); true }
        }
        val goBtn = Button(this).apply {
            text = "برو"
            setOnClickListener { go() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            addView(urlBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(goBtn)
        }

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        ua = web.settings.userAgentString
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url.toString()
                if (looksLikeMedia(u)) found(u, r.requestHeaders["Referer"] ?: pageUrl)
                return null
            }

            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                pageUrl = url
                urlBox.setText(url)
                items.clear(); seen.clear(); variantUrls.clear()
                updateFab()
            }

            override fun onPageFinished(v: WebView, url: String) {
                scan()
            }
        }
        web.setDownloadListener { url, _, _, mime, _ ->
            if (mime != null && mime.startsWith("video")) {
                start(Media(url, "", pageUrl, false, 0))
            } else {
                Toast.makeText(this, "فقط دانلود ویدیو پشتیبانی می‌شود", Toast.LENGTH_SHORT).show()
            }
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bar)
            addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        fab = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 15f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1E88E5"))
            }
            elevation = dp(6).toFloat()
            visibility = View.GONE
            setOnClickListener { showList() }
        }
        status = TextView(this).apply {
            setBackgroundColor(Color.parseColor("#DD000000"))
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
        }

        val root = FrameLayout(this)
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(
            fab,
            FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(16), dp(80))
            }
        )
        root.addView(
            status,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
        setContentView(root)

        web.loadUrl("https://www.google.com")
    }

    override fun onResume() {
        super.onResume()
        ui.post(scanner)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(scanner)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun go() {
        var t = urlBox.text.toString().trim()
        if (t.isEmpty()) return
        if (!t.startsWith("http")) {
            t = if (t.contains(".") && !t.contains(" ")) "https://$t"
            else "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(t)
    }

    // ---------- Detection ----------

    private fun path(u: String) = u.substringBefore('#').substringBefore('?').lowercase()

    private fun looksLikeMedia(u: String): Boolean {
        val p = path(u)
        return p.endsWith(".mp4") || p.endsWith(".m3u8") || p.endsWith(".webm") ||
            p.endsWith(".mkv") || p.endsWith(".mov") || p.endsWith(".m4v") ||
            p.endsWith(".flv") || p.endsWith(".3gp")
    }

    private fun scan() {
        val js = "(function(){var r=[];document.querySelectorAll('video,video source').forEach(function(e){" +
            "var s=e.currentSrc||e.src;if(s&&s.indexOf('http')===0)r.push(s)});return JSON.stringify(r)})()"
        web.evaluateJavascript(js) { raw ->
            try {
                val inner = JSONTokener(raw).nextValue() as? String ?: return@evaluateJavascript
                val arr = JSONArray(inner)
                for (i in 0 until arr.length()) found(arr.getString(i), pageUrl)
            } catch (_: Exception) {
            }
        }
    }

    private fun found(u: String, ref: String) {
        ui.post {
            if (!seen.add(u)) return@post
            io.execute { probe(u, ref) }
        }
    }

    private fun probe(u: String, ref: String) {
        val isHls = path(u).endsWith(".m3u8")
        try {
            if (isHls) {
                hlsEntries(u, ref)
                return
            }
            val c = open(u, ref, "HEAD")
            val len = c.contentLengthLong
            val type = (c.contentType ?: "").lowercase()
            c.disconnect()
            if (type.startsWith("text/") || type.contains("json") || type.startsWith("image/")) return
            if (type.contains("mpegurl")) {
                hlsEntries(u, ref)
                return
            }
            if (len in 1L..100_000L) return
            val ext = extOf(u, "mp4").uppercase()
            val label = if (len > 0) "$ext • ${fmt(len)}" else ext
            ui.post { add(Media(u, label, ref, false, 0)) }
        } catch (e: Exception) {
            ui.post { add(Media(u, if (isHls) "HLS" else "ویدیو", ref, isHls, 0)) }
        }
    }

    private fun hlsEntries(u: String, ref: String) {
        val txt = readText(u, ref)
        val v = parseVariants(txt, URL(u), ref)
        ui.post {
            if (v.isEmpty()) {
                add(Media(u, "HLS", ref, true, 0))
            } else {
                v.forEach { variantUrls.add(it.url) }
                items.removeAll { it.url in variantUrls && it.label == "HLS" }
                v.forEach { add(it) }
            }
        }
    }

    private fun parseVariants(txt: String, base: URL, ref: String): List<Media> {
        val lines = txt.lines().map { it.trim() }
        val list = ArrayList<Media>()
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.startsWith("#EXT-X-STREAM-INF")) continue
            val res = Regex("RESOLUTION=(\\d+)x(\\d+)").find(l)
            val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            var j = i + 1
            while (j < lines.size && (lines[j].isBlank() || lines[j].startsWith("#"))) j++
            if (j >= lines.size) continue
            val q = if (res != null) res.groupValues[2] + "p" else "${bw / 1000} kbps"
            list.add(Media(URL(base, lines[j]).toString(), "$q • HLS", ref, true, bw))
        }
        list.sortByDescending { it.bw }
        return list
    }

    private fun add(m: Media) {
        if (m.label == "HLS" && m.url in variantUrls) return
        if (items.any { it.url == m.url }) return
        items.add(m)
        updateFab()
    }

    private fun updateFab() {
        fab.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        fab.text = "⬇ ${items.size}"
    }

    private fun showList() {
        if (items.isEmpty()) return
        val names = items.map { it.label + "\n" + shortName(it.url) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("ویدیوهای پیدا شده - برای دانلود لمس کن")
            .setItems(names) { _, i -> start(items[i]) }
            .show()
    }

    private fun shortName(u: String) = u.substringBefore('?').substringAfterLast('/').take(40)

    // ---------- Network helpers ----------

    private fun open(u: String, ref: String, method: String = "GET"): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", ua)
        if (ref.isNotEmpty()) c.setRequestProperty("Referer", ref)
        CookieManager.getInstance().getCookie(u)?.let { c.setRequestProperty("Cookie", it) }
        return c
    }

    private fun readText(u: String, ref: String): String {
        val c = open(u, ref)
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun fetchBytes(u: String, ref: String): ByteArray {
        var err: Exception? = null
        repeat(3) {
            try {
                val c = open(u, ref)
                if (c.responseCode >= 400) throw IOException("HTTP ${c.responseCode}")
                return c.inputStream.use { it.readBytes() }
            } catch (e: Exception) {
                err = e
            }
        }
        throw (err ?: IOException("خطای دانلود"))
    }

    // ---------- Download ----------

    private fun progress(t: String) {
        ui.post { status.visibility = View.VISIBLE; status.text = t }
    }

    private fun start(m: Media) {
        progress("در حال شروع…")
        io.execute {
            try {
                val name = if (m.hls) downloadHls(m) else downloadDirect(m)
                progress("✅ ذخیره شد در Movies/VideoGrabber\n$name")
            } catch (e: Exception) {
                progress("❌ ${e.message ?: "خطا"}")
            }
            ui.postDelayed({ status.visibility = View.GONE }, 6000)
        }
    }

    private fun createOut(name: String, mime: String): Pair<Uri, java.io.OutputStream> {
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, mime)
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoGrabber")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
            ?: throw IOException("ساخت فایل ممکن نشد")
        val out = contentResolver.openOutputStream(uri) ?: throw IOException("باز کردن فایل ممکن نشد")
        return Pair(uri, out)
    }

    private fun finishOut(uri: Uri) {
        val cv = ContentValues()
        cv.put(MediaStore.Video.Media.IS_PENDING, 0)
        contentResolver.update(uri, cv, null, null)
    }

    private fun downloadDirect(m: Media): String {
        val c = open(m.url, m.ref)
        if (c.responseCode >= 400) throw IOException("خطای سرور ${c.responseCode}")
        val total = c.contentLengthLong
        val ext = extOf(m.url, "mp4")
        val name = "video_${System.currentTimeMillis()}.$ext"
        val (uri, out) = createOut(name, mimeOf(ext))
        try {
            out.use { o ->
                c.inputStream.use { i ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = 0L
                    var n = i.read(buf)
                    while (n >= 0) {
                        o.write(buf, 0, n)
                        done += n
                        val now = SystemClock.uptimeMillis()
                        if (now - last > 500) {
                            last = now
                            progress(if (total > 0) "⬇ ${done * 100 / total}%  (${fmt(done)})" else "⬇ ${fmt(done)}")
                        }
                        n = i.read(buf)
                    }
                }
            }
            finishOut(uri)
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
        return name
    }

    private fun downloadHls(m: Media): String {
        var url = m.url
        var txt = readText(url, m.ref)
        if (txt.contains("#EXT-X-STREAM-INF")) {
            val best = parseVariants(txt, URL(url), m.ref).firstOrNull()
                ?: throw IOException("کیفیتی پیدا نشد")
            url = best.url
            txt = readText(url, m.ref)
        }
        val base = URL(url)
        val seq = Regex("#EXT-X-MEDIA-SEQUENCE:(\\d+)").find(txt)?.groupValues?.get(1)?.toLongOrNull() ?: 0L

        var key: ByteArray? = null
        var ivAttr: ByteArray? = null
        var mapUrl: String? = null
        val segs = ArrayList<Seg>()
        var idx = 0L

        for (raw in txt.lines()) {
            val l = raw.trim()
            if (l.startsWith("#EXT-X-KEY")) {
                val method = Regex("METHOD=([^,]+)").find(l)?.groupValues?.get(1)
                if (method == "NONE") {
                    key = null; ivAttr = null
                } else if (method == "AES-128") {
                    val ku = Regex("URI=\"([^\"]+)\"").find(l)?.groupValues?.get(1)
                        ?: throw IOException("کلید رمزگشایی پیدا نشد")
                    key = fetchBytes(URL(base, ku).toString(), m.ref)
                    ivAttr = Regex("IV=0x([0-9A-Fa-f]+)").find(l)?.groupValues?.get(1)?.let { hexIv(it) }
                } else {
                    throw IOException("این ویدیو محافظت‌شده (DRM) است و قابل دانلود نیست")
                }
            } else if (l.startsWith("#EXT-X-MAP")) {
                val mu = Regex("URI=\"([^\"]+)\"").find(l)?.groupValues?.get(1)
                if (mu != null) mapUrl = URL(base, mu).toString()
            } else if (l.isNotEmpty() && !l.startsWith("#")) {
                val iv = if (key != null) (ivAttr ?: seqIv(seq + idx)) else null
                segs.add(Seg(URL(base, l).toString(), key, iv))
                idx++
            }
        }
        if (segs.isEmpty()) throw IOException("لیست قطعات خالی است")

        val ext = if (mapUrl != null) "mp4" else "ts"
        val name = "video_${System.currentTimeMillis()}.$ext"
        val (uri, out) = createOut(name, mimeOf(ext))
        try {
            out.use { o ->
                mapUrl?.let { o.write(fetchBytes(it, m.ref)) }
                for ((i, s) in segs.withIndex()) {
                    var data = fetchBytes(s.url, m.ref)
                    val k = s.key
                    val v = s.iv
                    if (k != null && v != null) {
                        val ci = Cipher.getInstance("AES/CBC/PKCS5Padding")
                        ci.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), IvParameterSpec(v))
                        data = ci.doFinal(data)
                    }
                    o.write(data)
                    progress("⬇ قطعه ${i + 1} از ${segs.size}")
                }
            }
            finishOut(uri)
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
        return name
    }

    private fun hexIv(s: String): ByteArray {
        val h = s.padStart(32, '0')
        return ByteArray(16) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    private fun seqIv(n: Long): ByteArray {
        val iv = ByteArray(16)
        for (i in 0..7) iv[15 - i] = (n shr (8 * i)).toByte()
        return iv
    }

    private fun extOf(u: String, def: String): String {
        val e = path(u).substringAfterLast('.', "")
        return if (e in setOf("mp4", "webm", "mkv", "mov", "m4v", "flv", "3gp")) e else def
    }

    private fun mimeOf(ext: String) = when (ext) {
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "3gp" -> "video/3gpp"
        "flv" -> "video/x-flv"
        "ts" -> "video/mp2t"
        else -> "video/mp4"
    }

    private fun fmt(b: Long): String =
        if (b >= 1048576) "%.1f MB".format(b / 1048576.0) else "${b / 1024} KB"
}
